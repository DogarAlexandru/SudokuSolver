from Controller import *
import operator
from timeit import default_timer as timer



class Ui:
    def __init__(self):
        self.con=controller()
        self.startMenu()

    def startMenu(self):
        s=input("For uninformed search press 1 , for informed press 2 , 3 to exit: ")
        while s!="1" and s!="2" and s!="3":
            s=input("Wrong input :\, try again :")
        if s=="1":
            if self.con.getSize()==4:
                self.create4by4(self.con.returnSol(self.con.bfs()))
            elif self.con.getSize()==9:
                self.create9by9(self.con.returnSol(self.con.bfs()))
        if s=="2":
            if self.con.getSize()==4:
                print(self.create4by4(self.con.returnSol(self.con.bestFS())))
            elif self.con.getSize()==9:
                self.create9by9(self.con.returnSol(self.con.bestFS()))

    def create4by4row(self,lista):
        poz = [3, 9, 18, 24]
        r = ""
        r = r + "|     |     |  |     |     |\n"
        rl = list(r)
        for i in range(0, 4):
            rl[poz[i]] = str(lista[i])
            if rl[poz[i]] == "0":
                rl[poz[i]] = " "
        r = ''.join(rl)
        return r

    def create4by4(self,list):
        t = ""
        close = "+-----------+  +-----------+\n"
        connect = "|-----+-----|  |-----+-----|\n"
        t = t + close
        t = t + create4by4row(list[0])
        t = t + connect
        t = t + create4by4row(list[1])
        t = t + close
        t = t + close
        t = t + create4by4row(list[2])
        t = t + connect
        t = t + create4by4row(list[3])
        t = t + close

        return t

    def create9by9row(self,lista):
        poz = [3, 9, 15, 24, 30, 36, 45, 51, 57]
        r = "|     |     |     |  |     |     |     |  |     |     |     |\n"
        rl = list(r)
        for i in range(0, 9):
            rl[poz[i]] = str(lista[i])
            if rl[poz[i]] == "0":
                rl[poz[i]] = " "
        r = ''.join(rl)
        return r

    def create9by9(self,list):
        close = "+-----------------+  +-----------------+  +-----------------+\n"
        connect = "|-----+-----+-----|  |-----+-----+-----|  |-----+-----+-----|\n"
        t = ""
        t = t + close
        t = t + create9by9row(list[0])
        t = t + connect
        t = t + create9by9row(list[1])
        t = t + connect
        t = t + create9by9row(list[2])
        t = t + close + "\n"

        t = t + close
        t = t + create9by9row(list[3])
        t = t + connect
        t = t + create9by9row(list[4])
        t = t + connect
        t = t + create9by9row(list[5])
        t = t + close + "\n"

        t = t + close
        t = t + create9by9row(list[6])
        t = t + connect
        t = t + create9by9row(list[7])
        t = t + connect
        t = t + create9by9row(list[8])
        t = t + close

        return t





