from UI import *

var=Ui()