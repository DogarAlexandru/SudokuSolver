import operator
from Problem import *
from timeit import default_timer as timer


#start = timer()


class controller:
    def __init__(self):
        self.prob=problem()

    def getSize(self):
        return self.prob.getSize()
    def bfs(self):

        q=[self.prob.getRoot()]
        while q:
            sol=q.pop(0)
            if self.prob.checkSolution(sol)==0:

                return sol
            else:
                q.extend(self.prob.expand(sol))
    def bestFS(self):
        q=[self.prob.getRoot()]
        while q:
            sol=q.pop(0)
            if sol.getMistakes()==0:
                return sol
            else:
                q.extend(self.prob.expand2(sol))
                q.sort(key=operator.attrgetter("mistakes"),reverse=False)

    def returnSol(self,st):
        matrix = self.prob.getStartup()
        cont = 0
        for i in range(self.prob.getSize()):
            for j in range(self.prob.getSize()):
                if matrix[i][j] == 0:
                    matrix[i][j] = st.getValues()[cont]
                    cont = cont + 1
        return matrix






#con=controller()
#con.bfs()
#con.bestFS()

#elapsed_time = timer() - start
#print(elapsed_time)

