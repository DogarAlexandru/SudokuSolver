def readFromFile():
    try:
        result = []
        f = open("input.txt", "r")
        line = f.readline().strip()
        while line != "":
            t = line.split(" ")
            while t.count(""):
                t.remove("")
            result.append(t)
            line = f.readline().strip()
        f.close()
    except IOError:
        print("Wrong file name or something")
    print(result)
    return result

def create4by4row(lista):
    poz=[3,9,18,24]
    r=""
    r=r+"|     |     |  |     |     |\n"
    rl=list(r)
    for i in range(0,4):
        rl[poz[i]]=str(lista[i])
        if rl[poz[i]]=="0":
            rl[poz[i]]=" "
    r=''.join(rl)
    return r

def create4by4(list):
    t=""
    close="+-----------+  +-----------+\n"
    connect="|-----+-----|  |-----+-----|\n"
    t=t+close
    t=t+create4by4row(list[0])
    t=t+connect
    t = t + create4by4row(list[1])
    t = t + close
    t = t + close
    t = t + create4by4row(list[2])
    t = t + connect
    t = t + create4by4row(list[3])
    t = t + close

    return t

def create9by9row(lista):
    poz=[3,9,15,24,30,36,45,51,57]
    r="|     |     |     |  |     |     |     |  |     |     |     |\n"
    rl = list(r)
    for i in range(0, 9):
        rl[poz[i]] = str(lista[i])
        if rl[poz[i]] == "0":
            rl[poz[i]] = " "
    r = ''.join(rl)
    return r

def create9by9(list):
    close="+-----------------+  +-----------------+  +-----------------+\n"
    connect="|-----+-----+-----|  |-----+-----+-----|  |-----+-----+-----|\n"
    t=""
    t=t+close
    t=t+create9by9row(list[0])
    t=t+connect
    t = t + create9by9row(list[1])
    t = t + connect
    t=t+create9by9row(list[2])
    t = t + close +"\n"

    t = t + close
    t = t + create9by9row(list[3])
    t = t + connect
    t = t + create9by9row(list[4])
    t = t + connect
    t = t + create9by9row(list[5])
    t = t + close + "\n"

    t = t + close
    t = t + create9by9row(list[6])
    t = t + connect
    t = t + create9by9row(list[7])
    t = t + connect
    t = t + create9by9row(list[8])
    t = t + close


    return t


#print(create9by9(readFromFile()))
import math
class state:
    def __init__(self, values):
        #values should be a LIST of INTEGERS
        self.values=values
        self.level=0
        self.mistakes=math.inf


    def getMistakes(self):
        return self.mistakes
    def setMistakes(self,m):
        self.mistakes=m

    def getValues(self):
        return self.values

    def getLevel(self):
        return self.level

    def raiseLevel(self):
        self.level=self.level+1













