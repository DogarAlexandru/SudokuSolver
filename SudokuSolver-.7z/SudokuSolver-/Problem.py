from State import *
import math
import copy
class problem:
    def __init__(self):
        self.setup=self.readFromFile()
        self.size = len(self.setup)
        self.root=state(self.getIntialState())

    def getStartup(self):
        return self.setup
    def getSize(self):
        return self.size

    def getIntialState(self):
        fin=[]
        help = []
        for i in range(self.size + 1):
            help.append(0)
        for i in range(self.size):
               for j in range(self.size):
                  help[self.setup[i][j]] = help[self.setup[i][j]] + 1
        for i in range(1,self.size + 1):
            while help[i]<self.size:
                fin.append(i)
                help[i]=help[i]+1

        return fin

    def readFromFile(self):
        try:
            result = []
            f = open("input2.txt", "r")
            line = f.readline().strip()
            while line != "":
                t = line.split(" ")
                while t.count(""):
                    t.remove("")
                for i in range(len(t)):
                    t[i]=int(t[i])
                result.append(t)
                line = f.readline().strip()
            f.close()
        except IOError:
            print("Wrong file name or something")

        return result

    def collumCount(self,matrix,collum,value):
        counter=0
        for i in range(self.size):
            if matrix[i][collum]==value:
                counter=counter+1
        return counter
    def collumList(self,matrix,collum):
        auxi=[]
        for i in range(self.size):
            auxi.append(matrix[i][collum])
        return auxi

    def checkSolution(self,state):
        matrix=copy.deepcopy(self.setup)
        mistakes=0
        cont=0
        for i in range(self.size):
            for j in range(self.size):
                if matrix[i][j]==0:
                    matrix[i][j]=state.getValues()[cont]
                    cont=cont+1
        for i in range(self.size):
            for j in range(self.size):
                    if matrix[i].count(matrix[i][j]) > 1:
                        mistakes=mistakes+1
        for i in range(self.size):
            for j in range(self.size):
                    if self.collumCount(matrix,j,matrix[i][j])>1:
                        mistakes = mistakes + 1
        squareRoot=int(math.sqrt(self.size))
        for i in range(squareRoot):
            for j in range(squareRoot):
                help=[]
                for k in range((i*squareRoot),((i+1)*squareRoot)):
                    for g in range((j*squareRoot),((j+1)*squareRoot)):
                        help.append(matrix[k][g])
                if len(help)!=len(set(help)):
                    mistakes = mistakes + 1
        return mistakes

    def checkSolution2(self,state):
        matrix=copy.deepcopy(self.setup)
        mistakes=0
        cont=0
        for i in range(self.size):
            for j in range(self.size):
                if matrix[i][j]==0:
                    matrix[i][j]=state.getValues()[cont]
                    cont=cont+1
        for i in range(self.size):
            if len(matrix[i])!=len(set(matrix[i])):
                mistakes=mistakes+1
        for i in range(self.size):
            if len(self.collumList(matrix,i))!=len(set(self.collumList(matrix,i))):
                mistakes=mistakes+1
        squareRoot=int(math.sqrt(self.size))
        for i in range(squareRoot):
            for j in range(squareRoot):
                help=[]
                for k in range((i*squareRoot),((i+1)*squareRoot)):
                    for g in range((j*squareRoot),((j+1)*squareRoot)):
                        help.append(matrix[k][g])
                if len(help)!=len(set(help)):
                    mistakes = mistakes + 1
        return mistakes

    def expand(self,st):
        auxi=[]
        for i in range(st.getLevel(),len(st.getValues())):
            aux=copy.deepcopy(st)
            aux.getValues()[aux.getLevel()],aux.getValues()[i]=aux.getValues()[i],aux.getValues()[aux.getLevel()]
            aux.raiseLevel()
            auxi.append(aux)
        return auxi
    def expand2(self,st):
        auxi=[]
        for i in range(st.getLevel(),len(st.getValues())):
            aux=copy.deepcopy(st)
            aux.getValues()[aux.getLevel()],aux.getValues()[i]=aux.getValues()[i],aux.getValues()[aux.getLevel()]
            aux.raiseLevel()
            aux.setMistakes(self.checkSolution(aux))
            auxi.append(aux)
        return auxi

    def getRoot(self):
        return self.root





#p=problem()
#print(p.getIntialState())
#print(p.checkSolution(p.root))
#list=p.expand(p.root)
#for i in list:
   # print( i.getValues())

